require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const {
  Client, GatewayIntentBits, EmbedBuilder, MessageFlags
} = require('discord.js');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const DB_PATH = path.join(__dirname, 'database.json');
const currency = process.env.CURRENCY_NAME || 'CLP';
const startBalance = Number(process.env.STARTING_BALANCE || 50000);
const workMin = Number(process.env.WORK_MIN || 5000);
const workMax = Number(process.env.WORK_MAX || 15000);
const dailyReward = Number(process.env.DAILY_REWARD || 10000);

function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    const initial = { users: {}, status: 'cerrado', transactions: [] };
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
    return initial;
  }
  try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); }
  catch { throw new Error('database.json está dañado. Detén el bot y restaura una copia de seguridad.'); }
}
let db = loadDB();
function saveDB() { fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2)); }
function account(id) {
  if (!db.users[id]) db.users[id] = { wallet: startBalance, bank: 0, lastDaily: 0, lastWork: 0 };
  return db.users[id];
}
function money(n) {
  return new Intl.NumberFormat('es-CL', { maximumFractionDigits: 0 }).format(n) + ' ' + currency;
}
function isAdmin(interaction) {
  if (interaction.memberPermissions?.has('Administrator')) return true;
  const roleId = process.env.ADMIN_ROLE_ID;
  return Boolean(roleId && interaction.member?.roles?.cache?.has(roleId));
}
function adminOnly(interaction) {
  if (isAdmin(interaction)) return true;
  interaction.reply({ content: '❌ No tienes permiso para usar este comando.', flags: MessageFlags.Ephemeral });
  return false;
}
function logTransaction(type, from, to, amount, note = '') {
  db.transactions.unshift({ type, from, to, amount, note, at: new Date().toISOString() });
  db.transactions = db.transactions.slice(0, 500);
}
async function announce(interaction, title, description, color) {
  const embed = new EmbedBuilder().setTitle(title).setDescription(description).setColor(color).setTimestamp();
  const channelId = process.env.ANNOUNCEMENT_CHANNEL_ID;
  const channel = channelId ? await client.channels.fetch(channelId).catch(() => null) : interaction.channel;
  if (!channel || !channel.isTextBased()) {
    return interaction.reply({ content: 'No pude encontrar el canal de anuncios. Revisa ANNOUNCEMENT_CHANNEL_ID.', flags: MessageFlags.Ephemeral });
  }
  await channel.send({ embeds: [embed] });
  await interaction.reply({ content: `✅ Anuncio enviado en ${channel}.`, flags: MessageFlags.Ephemeral });
}

client.once('ready', () => console.log(`Conectado como ${client.user.tag}`));
client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  try {
    const cmd = interaction.commandName;
    if (cmd === 'apertura') {
      if (!adminOnly(interaction)) return;
      db.status = 'abierto'; saveDB();
      return announce(interaction, '🟢 ¡ROLEPLAY ABIERTO!', 'Las sesiones de roleplay están oficialmente abiertas. ¡Ingresen y respeten el reglamento!', 0x2ecc71);
    }
    if (cmd === 'cierre') {
      if (!adminOnly(interaction)) return;
      db.status = 'cerrado'; saveDB();
      return announce(interaction, '🔴 ROLEPLAY CERRADO', 'La sesión de roleplay ha finalizado. Gracias por participar.', 0xe74c3c);
    }
    if (cmd === 'estado') {
      const open = db.status === 'abierto';
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('Estado del roleplay').setDescription(open ? '🟢 **ABIERTO**' : '🔴 **CERRADO**').setColor(open ? 0x2ecc71 : 0xe74c3c)] });
    }
    if (cmd === 'saldo') {
      const user = interaction.options.getUser('usuario') || interaction.user;
      const a = account(user.id); saveDB();
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle(`💳 Economía de ${user.username}`).setThumbnail(user.displayAvatarURL()).addFields(
        { name: '💵 Efectivo', value: money(a.wallet), inline: true },
        { name: '🏦 Banco', value: money(a.bank), inline: true },
        { name: '💰 Total', value: money(a.wallet + a.bank), inline: true }
      ).setColor(0x3498db)] });
    }
    if (cmd === 'dar_dinero' || cmd === 'quitar_dinero') {
      if (!adminOnly(interaction)) return;
      const user = interaction.options.getUser('usuario');
      const amount = interaction.options.getInteger('cantidad');
      const tipo = interaction.options.getString('tipo') || 'efectivo';
      if (user.bot) return interaction.reply({ content: 'No puedes modificar la cuenta de un bot.', flags: MessageFlags.Ephemeral });
      const a = account(user.id);
      const key = tipo === 'banco' ? 'bank' : 'wallet';
      if (cmd === 'quitar_dinero' && a[key] < amount) return interaction.reply({ content: `❌ ${user} solo tiene ${money(a[key])} en ${tipo}.`, flags: MessageFlags.Ephemeral });
      a[key] += cmd === 'dar_dinero' ? amount : -amount;
      logTransaction(cmd, interaction.user.id, user.id, amount, tipo); saveDB();
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('✅ Movimiento administrativo').setDescription(`${cmd === 'dar_dinero' ? 'Se entregaron' : 'Se retiraron'} **${money(amount)}** ${cmd === 'dar_dinero' ? 'a' : 'de'} ${user} (${tipo}).`).addFields({name:'Nuevo saldo', value:money(a.wallet + a.bank)}).setColor(cmd === 'dar_dinero' ? 0x2ecc71 : 0xe67e22)] });
    }
    if (cmd === 'pagar') {
      const user = interaction.options.getUser('usuario');
      const amount = interaction.options.getInteger('cantidad');
      if (user.id === interaction.user.id || user.bot) return interaction.reply({ content: '❌ Elige a otro jugador, no a ti mismo ni a un bot.', flags: MessageFlags.Ephemeral });
      const sender = account(interaction.user.id);
      if (sender.wallet < amount) return interaction.reply({ content: `❌ No tienes suficiente efectivo. Tienes ${money(sender.wallet)}.`, flags: MessageFlags.Ephemeral });
      const receiver = account(user.id);
      sender.wallet -= amount; receiver.wallet += amount;
      logTransaction('pago', interaction.user.id, user.id, amount); saveDB();
      return interaction.reply({ content: `✅ ${interaction.user} pagó **${money(amount)}** a ${user}.` });
    }
    if (cmd === 'depositar' || cmd === 'retirar') {
      const amount = interaction.options.getInteger('cantidad');
      const a = account(interaction.user.id);
      const from = cmd === 'depositar' ? 'wallet' : 'bank';
      const to = cmd === 'depositar' ? 'bank' : 'wallet';
      if (a[from] < amount) return interaction.reply({ content: `❌ Fondos insuficientes. Disponible: ${money(a[from])}.`, flags: MessageFlags.Ephemeral });
      a[from] -= amount; a[to] += amount;
      logTransaction(cmd, interaction.user.id, interaction.user.id, amount); saveDB();
      return interaction.reply({ content: `✅ ${cmd === 'depositar' ? 'Depositaste' : 'Retiraste'} **${money(amount)}**.\n💵 Efectivo: ${money(a.wallet)}\n🏦 Banco: ${money(a.bank)}` });
    }
    if (cmd === 'trabajar') {
      const a = account(interaction.user.id), now = Date.now();
      const cooldown = 60 * 60 * 1000;
      if (now - a.lastWork < cooldown) {
        const mins = Math.ceil((cooldown - (now - a.lastWork)) / 60000);
        return interaction.reply({ content: `⏳ Ya trabajaste. Vuelve en aproximadamente **${mins} minutos**.`, flags: MessageFlags.Ephemeral });
      }
      const amount = Math.floor(Math.random() * (workMax - workMin + 1)) + workMin;
      a.wallet += amount; a.lastWork = now; logTransaction('trabajo', null, interaction.user.id, amount); saveDB();
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('🧰 Jornada completada').setDescription(`Ganaste **${money(amount)}** por tu trabajo.`).addFields({name:'Efectivo actual',value:money(a.wallet)}).setColor(0x2ecc71)] });
    }
    if (cmd === 'diario') {
      const a = account(interaction.user.id), now = Date.now();
      const day = 24 * 60 * 60 * 1000;
      if (now - a.lastDaily < day) {
        const hours = Math.ceil((day - (now - a.lastDaily)) / 3600000);
        return interaction.reply({ content: `🎁 Ya reclamaste tu bono diario. Vuelve en aproximadamente **${hours} horas**.`, flags: MessageFlags.Ephemeral });
      }
      a.wallet += dailyReward; a.lastDaily = now; logTransaction('diario', null, interaction.user.id, dailyReward); saveDB();
      return interaction.reply({ content: `🎁 Recibiste **${money(dailyReward)}**. Tu efectivo ahora es **${money(a.wallet)}**.` });
    }
    if (cmd === 'ranking') {
      const rows = Object.entries(db.users).map(([id,a]) => ({id,total:a.wallet+a.bank})).sort((a,b)=>b.total-a.total).slice(0,10);
      const lines = rows.length ? rows.map((r,i)=>`**${i+1}.** <@${r.id}> — ${money(r.total)}`).join('\n') : 'Todavía no hay cuentas registradas.';
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('🏆 Ranking de riqueza').setDescription(lines).setColor(0xf1c40f)] });
    }
    if (cmd === 'historial') {
      if (!adminOnly(interaction)) return;
      const rows = db.transactions.slice(0,10);
      const lines = rows.map(t=>`• **${t.type}** — ${money(t.amount)} — <@${t.to || t.from}> — ${new Date(t.at).toLocaleString('es-CL')}`).join('\n') || 'No hay movimientos todavía.';
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('📋 Últimos movimientos').setDescription(lines).setColor(0x5865f2)], flags: MessageFlags.Ephemeral });
    }
  } catch (error) {
    console.error(error);
    const payload = { content: 'Ocurrió un error. Revisa la consola del bot.', flags: MessageFlags.Ephemeral };
    if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(()=>{});
    else await interaction.reply(payload).catch(()=>{});
  }
});
client.login(process.env.DISCORD_TOKEN);
