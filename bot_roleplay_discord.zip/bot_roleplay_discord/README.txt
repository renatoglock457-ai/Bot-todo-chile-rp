BOT DE DISCORD PARA ROLEPLAY — GUÍA RÁPIDA

REQUISITOS
- Node.js LTS instalado en el computador.
- Una aplicación/bot creado en Discord Developer Portal.
- Permiso para añadir el bot al servidor.

INSTALACIÓN
1. Descomprime el ZIP en una carpeta.
2. Instala Node.js LTS desde https://nodejs.org/
3. En Discord Developer Portal (https://discord.com/developers/applications), crea una aplicación y entra a la sección Bot. Crea el bot y copia su token. NO compartas el token con nadie.
4. En OAuth2 > General copia el Application ID (CLIENT_ID).
5. Activa OAuth2 > URL Generator y marca scopes: bot y applications.commands. En permisos del bot marca Send Messages y Embed Links. Abre el enlace generado para invitarlo a tu servidor.
6. Copia .env.example y renombra la copia a .env.
7. Completa DISCORD_TOKEN, CLIENT_ID, GUILD_ID y ADMIN_ROLE_ID. Los IDs se copian activando Modo desarrollador en Discord > Ajustes > Avanzado > Modo desarrollador, y luego clic derecho/toque prolongado en servidor o rol > Copiar ID.
8. Abre una terminal dentro de la carpeta y ejecuta:
   npm install
   npm run register
   npm start

COMANDOS
/apertura — anunciar que RP abre (administración)
/cierre — anunciar que RP cierra (administración)
/estado — consultar estado
/saldo [usuario] — consultar efectivo y banco
/dar_dinero usuario cantidad tipo — entregar dinero (administración)
/quitar_dinero usuario cantidad tipo — retirar dinero (administración)
/pagar usuario cantidad — pagar a otro jugador
/depositar cantidad — pasar efectivo al banco
/retirar cantidad — pasar dinero del banco al efectivo
/trabajar — ganar dinero; espera de una hora
/diario — bono cada 24 horas
/ranking — top 10 por riqueza
/historial — últimos movimientos (administración)

DATOS
- La economía se guarda en database.json y persiste tras reiniciar el bot.
- Haz copias de seguridad de database.json.
- El archivo .env contiene secretos: nunca lo subas a GitHub ni lo compartas.
- Esta versión usa JSON para un servidor pequeño. Para un bot grande conviene migrar a SQLite o PostgreSQL.
- La moneda inicial es CLP y el saldo inicial predeterminado es $50.000 ficticios de roleplay. Puedes cambiarlo en .env.
