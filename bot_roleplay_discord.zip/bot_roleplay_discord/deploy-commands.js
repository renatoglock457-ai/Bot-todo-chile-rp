require('dotenv').config();
const { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const admin = { default_member_permissions: PermissionFlagsBits.Administrator.toString() };
const commands = [
  new SlashCommandBuilder().setName('apertura').setDescription('Anuncia la apertura del roleplay').setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('cierre').setDescription('Anuncia el cierre del roleplay').setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('estado').setDescription('Consulta si el roleplay está abierto o cerrado'),
  new SlashCommandBuilder().setName('saldo').setDescription('Consulta el saldo de una cuenta').addUserOption(o=>o.setName('usuario').setDescription('Jugador (opcional)').setRequired(false)),
  new SlashCommandBuilder().setName('dar_dinero').setDescription('Entrega dinero a un jugador (administración)').setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption(o=>o.setName('usuario').setDescription('Jugador').setRequired(true))
    .addIntegerOption(o=>o.setName('cantidad').setDescription('Cantidad positiva').setMinValue(1).setMaxValue(1000000000).setRequired(true))
    .addStringOption(o=>o.setName('tipo').setDescription('Cuenta a modificar').addChoices({name:'Efectivo',value:'efectivo'},{name:'Banco',value:'banco'}).setRequired(true)),
  new SlashCommandBuilder().setName('quitar_dinero').setDescription('Retira dinero de un jugador (administración)').setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption(o=>o.setName('usuario').setDescription('Jugador').setRequired(true))
    .addIntegerOption(o=>o.setName('cantidad').setDescription('Cantidad positiva').setMinValue(1).setMaxValue(1000000000).setRequired(true))
    .addStringOption(o=>o.setName('tipo').setDescription('Cuenta a modificar').addChoices({name:'Efectivo',value:'efectivo'},{name:'Banco',value:'banco'}).setRequired(true)),
  new SlashCommandBuilder().setName('pagar').setDescription('Paga efectivo a otro jugador')
    .addUserOption(o=>o.setName('usuario').setDescription('Jugador que recibirá el dinero').setRequired(true))
    .addIntegerOption(o=>o.setName('cantidad').setDescription('Cantidad positiva').setMinValue(1).setMaxValue(1000000000).setRequired(true)),
  new SlashCommandBuilder().setName('depositar').setDescription('Deposita efectivo en el banco')
    .addIntegerOption(o=>o.setName('cantidad').setDescription('Cantidad positiva').setMinValue(1).setMaxValue(1000000000).setRequired(true)),
  new SlashCommandBuilder().setName('retirar').setDescription('Retira dinero del banco')
    .addIntegerOption(o=>o.setName('cantidad').setDescription('Cantidad positiva').setMinValue(1).setMaxValue(1000000000).setRequired(true)),
  new SlashCommandBuilder().setName('trabajar').setDescription('Trabaja para ganar dinero (1 hora de espera)'),
  new SlashCommandBuilder().setName('diario').setDescription('Reclama tu bono diario'),
  new SlashCommandBuilder().setName('ranking').setDescription('Muestra el top 10 de riqueza'),
  new SlashCommandBuilder().setName('historial').setDescription('Muestra los últimos movimientos (administración)').setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
].map(c=>c.toJSON());

(async()=>{
  if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID || !process.env.GUILD_ID) {
    console.error('Completa DISCORD_TOKEN, CLIENT_ID y GUILD_ID en el archivo .env');
    process.exit(1);
  }
  const rest = new REST({version:'10'}).setToken(process.env.DISCORD_TOKEN);
  await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), {body:commands});
  console.log('Comandos registrados en el servidor:', process.env.GUILD_ID);
})().catch(e=>{console.error(e);process.exit(1);});
